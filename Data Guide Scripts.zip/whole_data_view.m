% ===================================================================== %
%Readme:                                                                %
%This script can be run headlessly.                                     %
%This outputs the overview of the compiled reconstructed images         %
% --------------------------------------------------------------------- %

function image=whole_data_view()

load Baybayin_A.mat Baybayin_A1000;
data1=Baybayin_A1000; %data1 = square image feature vector data
img_size=56; %img_size = image row/col size
tic;
[row, col]=size(data1);
r=ceil(sqrt(row));
B=zeros(r*img_size);
c=r^2-row;
cc=zeros(c,col);

%padded_data1=zeros(r^2);
padded_data1=[data1;cc];

   for p=1:r
       
    for j=1:r 
    Z=zeros(img_size);
         
          
        for i=1:img_size
            Z(i,:)=padded_data1((p*r)-(r-j),img_size*(i-1)+1:i*img_size);
        end
    B(img_size*(j-1)+1:j*img_size,img_size*(p-1)+1:p*img_size)=Z(:,:);  
   
    end
   end 
   figure;
image=imshow(B);
toc;
end