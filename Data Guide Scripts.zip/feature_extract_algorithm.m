% ----------------------------------------------------------------------------------------
% Feature Extraction Algorithm                                                           %                           
% by Rodney Pino, Renier Mendoza and Rachelle Sambayan                                   %
% Programmed by Rodney Pino at University of the Philippines - Diliman                   %
% Programming dates: Feb 2020 to September 2020                                          % 
% ----------------------------------------------------------------------------------------


function Letter1=feature_extract_algorithm(input)
%Example: A=feature_extract_algorithm('Da_noisy.PNG');
%         A=feature_extract_algorithm('Ga_noisy.PNG');
%         A=feature_extract_algorithm('Na_noisy.PNG');
%         A=feature_extract_algorithm('EI_noisy.PNG');


%---------------------------------Start of preprocessing---------------------------------%  
u=imread(input);
[~,v2]=c2bw(u);
Letter2=v2;
s=regionprops(Letter2,'basic');
ss=struct2cell(s);
S=cell2mat(ss(1,:));

%===================================================================================
%If more than one component, this part is intended for the Baybayin character 'E/I'
if length(S)>=2
EE=max(S)/max(S(S<max(S)))-1;
if EE<=1
    %Identifying the main body's significant features or bounding box
    L=find(S==max(S)); 
    SS=max(S(S<max(S)));
    LL=find(S==SS);
    
    B=ss(:,L);
    BB=ss(:,LL);
    
    A=cat(1,B{3},BB{3});
    AA(1)=min(A(:,1)); AA(2)=min(A(:,2)); AA(3)=max(A(:,3)); AA(4)=abs(A(1,2)-A(2,2));
    if A(1,2)>A(2,2)
       AA(4)=AA(4)+A(1,4);
    else
       AA(4)=AA(4)+A(2,4);
    end
    
    Letter=imcrop(Letter2,AA); %Cropping the main body with only its essential features
    
    Letter=imresize(Letter,[56 56]); %Rescaling the cropped image
    
    Letter=bwareaopen(Letter, 10); %Denoising of the 56x56 size image
     
    Letter1=feature_vector_extractor(Letter); %feature vector extraction
    return;
end
end
%-----------------------------------------------------------------------------------


%Identifying the main body's significant features or bounding box
L=find(S==max(S));

SS=max(S(S<max(S)));
LL=find(S==SS);

B=ss(:,L);
BB=ss(:,LL);

b=B{2};
b=b(2);


L=find(S==max(S));
B=ss(:,L);
A=B{3};
A(1)=A(1)-1; A(2)=A(2)-1; A(3)=A(3)+1; A(4)=A(4)+1;

%Cropping the main body with only its essential features
Letter=imcrop(Letter2,A);

%Rescaling the cropped image
M=56;
Letter=imresize(Letter, [M M]);
R1=regionprops(Letter,'Area');
R2=struct2cell(R1);
R3=cell2mat(R2(1,:));

%Denoising of the 56x56 size image
if length(R3)>=2
    R4=max(R3(R3<max(R3)));
    Letter=bwareaopen(Letter, R4+1);
else
    Letter=bwareaopen(Letter, 10);
end

%feature vector extraction
Letter1=feature_vector_extractor(Letter);
