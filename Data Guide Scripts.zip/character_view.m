% ===================================================================== %
%Readme:                                                                %
%This script can be run headlessly.                                     %
%This outputs a particular character from the compiled reconstructed    %
%images                                                                 % 
%---------------------------------------------------------------------- %

function character_view()

load Baybayin_A.mat Baybayin_A1000;
data1=Baybayin_A1000; %data1 = square image feature vector data
row_num=25; %row_num = the particular row of the image you want to view; in this case, you will view the 25th image of Baybayin A
img_size=56; %img_size = image row/col size

Z=zeros(img_size);
for i=1:img_size
Z(i,:)=data1(row_num,img_size*(i-1)+1:i*img_size);
end
figure;
imshow(Z)
