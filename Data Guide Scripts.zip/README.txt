The Data Guide Scripts zip file contains MATLAB codes/functions that are used to reconstruct and validate each image data.  

Normalization codes:
feature_extract_algorithm.m - this is the mother code to execute the feature extraction process of a raw Baybayin character, starting from binarization to extraction of its feature vector.

kmeans_mod.m - this is a subfunction from the feature_extract_algorithm.m for clustering a grayscaled image into 2 intensities intended for image binarization.

c2bw.m - this is a subfunction from the feature_extract_algorithm.m for converting the input raw image into binary image using the modified kmeans function.

feature_vector_extractor.m - this is a subfunction from the feature_extract_algorithm.m that outputs the 1x3136 feature vector array of the input square matrix.



Run headlessly:
character_view - use to view a single character image from the compiled dataset.

whole_data_view - use to view a clustered dataset.

Model generators:

BINARY - these functions generate binary classifiers for Script classification (Latin and Baybayin), Baybayin diacritics categorization, and binary classifiers for confusive Baybayin characters.
data_trainingtesting_binary_KNN.m - generates KNN binary models. 
data_trainingtesting_binary_SVM.m - generates SVM binary models.

MULTICLASS - these functions generate multiclass classifiers in recognizing the 17 Baybayin characters.
data_traintest3_multiclass_17classes_revisedKNN.m - generates KNN multiclass models.
data_traintest3_multiclass_17classes_revisedSVM.m - generates SVM multiclass models.


Sample variable and images:
Baybayin_A.mat - contains the 1,000 reconstructed images of Baybayin character A
Da_noisy.PNG - noisy image of a Baybayin character Da
EI_noisy.PNG - noisy image of a Baybayin character E/I
Ga_noisy.PNG - noisy image of a Baybayin character Ga
Na_noisy.PNG - noisy image of a Baybayin character Na

